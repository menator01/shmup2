import pygame
import os
from random import shuffle

class Music:
    ''' Class for playing the background music '''
    def __init__(self, path):
        self.tracks = os.listdir(f'{path}/media/music')
        self.path = path

    def play(self):
        ''' Play the music '''
        tracks = []
        if not tracks:
            tracks = self.tracks.copy()
            shuffle(tracks)
        track = tracks.pop(0)
        pygame.mixer.music.load(f'{self.path}/media/music/{track}')
        pygame.mixer.music.set_volume(0.3)
        pygame.mixer.music.play()
        