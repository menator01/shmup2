from modules.mysprites import allsprites
from modules.armory import Missile, Laser
from modules.effects import Explosion
import pygame, os
from random import choice, randint, randrange

# Create needed sprite groups for collision detections
player_sprite = pygame.sprite.Group()
weapon_sprite = pygame.sprite.Group()
mob_sprite = pygame.sprite.Group()

class Player(pygame.sprite.Sprite):
    ''' Class for creating the player '''
    def __init__(self, path):
        pygame.sprite.Sprite.__init__(self)
        self.path = path
        img = pygame.image.load(f'{path}/media/images/ships/myship.png')
        self.image = pygame.transform.scale(img, (50,50))
        self.image.set_colorkey('black')
        self.rect = self.image.get_rect()
        self.radius = 25
        self.rect.centerx = 640
        self.rect.bottom = 705
        self.speedx = 0
        self.hidden = False
        self.life = 100
        self.lives = 3
        self.score = 0
        self.type = 'player'
        self.laser_fire = False
        self.laser_timer = None
        self.hide_timer = pygame.time.get_ticks()
        player_sprite.add(self)
        allsprites.add(self)

    def hide(self):
        ''' Method for hiding player when killed '''
        self.hidden = True
        self.hide_timer = pygame.time.get_ticks()
        self.rect.center = (640, 800)

    def missile(self):
        ''' Method for creating the missile when fired '''
        missile = Missile(self.rect.centerx, self.rect.top, self.path)
        weapon_sprite.add(missile)
        allsprites.add(missile)      

    def laser(self):
        ''' Method for firing the laser '''
        laser = laser = Laser(self.rect.centerx, self.rect.top, self.path)
        weapon_sprite.add(laser)
        allsprites.add(laser)
        

    def update(self):
        ''' Update all movements '''
        if self.hidden and pygame.time.get_ticks() - self.hide_timer > 1000:
            self.hidden = False
            self.rect.centerx = 640
            self.rect.bottom = 705

        # Movement
        self.speedx = 0
        keystate = pygame.key.get_pressed()
        if keystate[pygame.K_LEFT] or keystate[pygame.K_a]:
            self.speedx = -8
        if keystate[pygame.K_RIGHT] or keystate[pygame.K_d]:
            self.speedx = 8

        self.rect.x += self.speedx

        if self.rect.right > 1265:
            self.rect.right = 1265
        if self.rect.left < 15:
            self.rect.left = 15

        # Creates the explosion when player dies
        if self.life <= 0:
            self.explosion = Explosion(self.path, self.rect.center, user=True)

    
class Mob(pygame.sprite.Sprite):
    ''' Class for creating the mobs '''
    def __init__(self, path):
        pygame.sprite.Sprite.__init__(self)
        self.path = path
        excludes = ['myship.png', 'myship2.png']
        ships = os.listdir(f'{path}/media/images/ships')
        ships = [pygame.image.load(f'{path}/media/images/ships/{ship}') \
                 for ship in ships if ship not in excludes]
        
        self.image = pygame.transform.scale(choice(ships), \
                                            (randint(25,45), randint(25,45)))
        
        self.image.set_colorkey('black')
        self.rect = self.image.get_rect()
        self.radius = (self.rect.width * .80)
        self.rect.x = randrange(self.rect.width, (1280 - self.rect.width))
        self.rect.y = randrange(-30, -5)
        self.speedx = randrange(-3, 3)
        self.speedy = randrange(2, 6)

        mob_sprite.add(self)

    def newmob(self):
        ''' Methos for creating new mobs '''
        mob = Mob(self.path)

    def update(self):
        ''' Method for updating everything '''
        self.rect.x += self.speedx
        self.rect.y += self.speedy

        if self.rect.top > 730 or self.rect.left < 0 or self.rect.right > 1280:
            self.rect.x = randrange(0, 1280-self.rect.width)
            self.rect.y = randrange(-30, -5)
            self.speedx = randrange(-3, 3)
            self.speedy = randrange(5, 8)

        if self.rect.top > 720:
            self.kill()
            self.newmob()

           

