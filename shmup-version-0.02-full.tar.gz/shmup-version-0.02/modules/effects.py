import pygame
import os
from modules.mysprites import allsprites

class Explosion(pygame.sprite.Sprite):
    ''' This class creates and handles the explosion animation on the game screen '''
    def __init__(self, path, rect, user=False):
        pygame.sprite.Sprite.__init__(self)
        self.path = path
        self.frame = 0

        # Which explosion type
        if user:
            imgpath = f'{path}/media/images/animation/player'
        else:
            imgpath = f'{path}/media/images/animation/enemy'

        files = os.listdir(imgpath)
        self.myimgs = []
        for i, file in enumerate(files):

            # Make sure we are getting the right images
            if user:
                file = pygame.image.load(f'{imgpath}/Explosion_{i}.png')
            else:
                file = pygame.image.load(f'{imgpath}/explosion1_{i}.png')
            self.myimgs.append(file)

        self.image = self.myimgs[0]
        self.rect = self.image.get_rect()
        self.rect.center = rect

        # Get the correct explosion sound
        if user:
            sound = pygame.mixer.Sound(f'{path}/media/sounds/myexplosion.wav')
        else:
            sound = pygame.mixer.Sound(f'{path}/media/sounds/explosion.wav')
        sound.set_volume(0.3)
        sound.play()

        # Add to the allsprites group
        allsprites.add(self)
        
    def update(self):
        ''' Update the explosion frame '''
        self.frame += 1
        if self.frame >= len(self.myimgs):
            self.kill()
        else:
            self.image = self.myimgs[self.frame] 