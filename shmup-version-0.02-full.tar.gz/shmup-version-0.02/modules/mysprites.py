''' Used for sprites that do not need collision detection '''
import pygame
allsprites = pygame.sprite.Group()


