import sys, os
from modules import abient, database
import pygame
from random import choice
from time import time

# Initiate pygame fonts
pygame.font.init()

# Setup our path to access game root folder
tmp = os.path.realpath(os.path.dirname(__file__)).split('/')
tmp.pop()
path = '/'.join(tmp)


# Function to create text labels
def label(text, size, color, font, x=0, y=0, underline=False):   
    font = pygame.font.Font(f'{path}/media/fonts/{font}', size)
    font.underline=underline
    text = font.render(text, True, color)
    width = 1280
    text_w = text.get_rect().width
    pos = ((width/2-text_w/2)+x, y)
    return text, pos

# Create an empty label list and store our labels/text
labels = []
labels.append(label('Shmup', 80, (0,0,0), 'Nosifer-Regular.ttf', x=3, y=3))
labels.append(label('Shmup', 80, (255,0,255), 'Nosifer-Regular.ttf'))

labels.append(label('Beta Version 0.02', 22, (0,0,0), 'FreeMonoBoldOblique.ttf', x=1283/3, y=38))
labels.append(label('Beta Version 0.02', 22, (200,200,200), 'FreeMonoBoldOblique.ttf', x=1280/3, y=35))

labels.append(label('Powered by pygame 2.5.2 (SDL 2.28.2, Python 3.12.0)', 22, (0,0,0), 'FreeMonoBoldOblique.ttf', x=3, y=123))
labels.append(label('Powered by pygame 2.5.2 (SDL 2.28.2, Python 3.12.0)', 22, 'lime', 'FreeMonoBoldOblique.ttf', y=120))

labels.append(label('Top 5 Scores', 45, 'black', 'Nosifer-Regular.ttf', x=3, y=153, underline=True))
labels.append(label('Top 5 Scores', 45, 'orange', 'Nosifer-Regular.ttf', y=150, underline=True))

labels.append(label(f'Gaming-Rat Productions{chr(169)} 2020', 22, (0,0,0), 'FreeMonoBoldOblique.ttf',x=-374, y=672))
labels.append(label(f'Gaming-Rat Productions{chr(169)} 2020', 22, (255,230,230), 'FreeMonoBoldOblique.ttf',x=-376, y=670))

labels.append(label('Press spacebar to start', 35, (0,0,0), 'calibri.ttf', y=720-220))
labels.append(label('Gives Shield', 32, (0,0,0), 'calibri.ttf', x=-295, y=600))
labels.append(label('Partial Health', 30, (0,0,0), 'calibri.ttf', x=0, y=600))
labels.append(label('Full Health', 32, (0,0,0), 'calibri.ttf', x=295, y=600))


# Make a list of ships in the ship directory
ships = os.listdir(f'{path}/media/images/ships')

# Function for placing images
def placeimg(rotate, apath, ship, width=64, height=64):
    img = pygame.image.load(f'{path}/{apath}/{ship}')
    img = pygame.transform.scale(img, (width, height))
    img = pygame.transform.rotate(img, rotate)
    img.set_colorkey('black')
    return img

# Create some images for the screen
ship1 = placeimg(45, 'media/images/ships',choice(ships))
ship2 = placeimg(-45, 'media/images/ships', choice(ships))

shield = placeimg(0, 'media/images/powerups', 'shield.png', width=48, height=48)
health1 = placeimg(0, 'media/images/powerups', 'partial_life.png', width=48, height=48)
health2 = placeimg(0, 'media/images/powerups', 'full_life.png', width=48, height=48)

logo = pygame.image.load(f'{path}/media/images/icons/ratt2b.bmp')

# Connect, create, and query database
db = database.Database(path)
db.create()

class Title:
    ''' Class is the start page when game is executed '''
    def __init__(self, screen):
        # Background music and image
        music = abient.Music(path)
        bgimg = pygame.image.load(f'{path}/media/images/backgrounds/title.jpeg')
        bgimg_rect = bgimg.get_rect()

        # Starting index for entry placements on the screen
        gamers = db.top5()
        index = 220

        # Loop through the database call and print out top 5 scores
        for data in gamers:
            name, score, date = data
            labels.append(label(f'{name.upper()} {score} {date}', 35, 'black', 'calibri.ttf', x=2, y=index+2))
            labels.append(label(f'{name.upper()} {score} {date}', 35, 'white', 'calibri.ttf', y=index))
            index += 50     

        while True:
            # For the background music
            if not pygame.mixer.music.get_busy():
                music.play()

            # Background image
            screen.blit(bgimg, bgimg_rect)

            # Icon images
            screen.blit(ship1, (180, 175))
            screen.blit(ship2, (1000, 175))

            screen.blit(shield, (315, 545))
            screen.blit(health1, (screen.get_rect().width/2-25, 545))
            screen.blit(health2, (905, 545))

            screen.blit(logo, (25,640))

            # Get pygame events
            event = pygame.event.poll()
            if event.type == pygame.QUIT:
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    sys.exit()

                if event.key == pygame.K_SPACE:
                    break

            # Blit all the labels
            for alabel in labels:
                screen.blit(alabel[0], alabel[1])


            pygame.display.update()


class TextBox:
    '''
        TextBox class will create an input box to enter text
        Also provides a header text for the box
    '''
    def __init__(self, header_text):
        self.name = []
        
        self.font = pygame.font.Font(None, 40)

        # Create our header
        self.head_surface = self.font.render(header_text, True, 'white')

        # Create input box
        self.rect = pygame.Rect(650, 110, 200, 35)

        # Set a text variable
        self.text = ''

        # Create a text surface
        self.text_surface = self.font.render(self.text, True, 'black')

        # Get the text rect
        self.text_rect = self.text_surface.get_rect()

        # Create a cursor
        self.cursor = pygame.Rect(self.text_rect.topright, (3, self.text_rect.height))

        self.btncolor = 'royalblue'

    def draw(self, screen):
        # Draw everthing to the screen

        screen.blit(self.head_surface, (450, self.rect.y+10))

        pygame.draw.rect(screen, 'white', self.rect)

        screen.blit(self.text_surface, (self.rect.x+5, self.rect.y+3))
        pygame.draw.rect(screen, 'black', self.rect, 1)

        # Give the cursor a blinking effect
        if time() % 1 > 0.5:
            text_rect = self.text_surface.get_rect(topleft=(self.rect.x+5, self.rect.y+3))
            self.cursor.midleft = text_rect.midright
            pygame.draw.rect(screen, 'black', self.cursor)

    def add(self, text):
        # Add text to the input box
        self.text += text

    def delete(self):
        # Remove text from input box
        self.text = self.text[:-1]
        self.name = self.name[:-1]

    def update(self):
        # Update everything
        self.text_surface = self.font.render(self.text, True, 'black')
        width = max(200, self.text_surface.get_width()+10)
        self.rect.w = width
        

    def myevents(self, event, screen, player):
        # Check pygame events for a key press
        if event.type == pygame.KEYDOWN:

            # If the backspace is pressed remove text
            # Else add the text
            if event.key == pygame.K_BACKSPACE:
                if len(self.text) > 0:
                    self.delete()
            else:
                # Allow only letters, numbers and space in the input box
                if event.unicode.isalnum():

                    # Limiting only to thre letters
                    if len(self.text) >= 3:
                        self.delete()
                    
                    # Add to input box
                    self.add(event.unicode)

                    # Append letters to list
                    self.name.append(event.unicode)
                    

        # Create a button
        smfont = pygame.font.Font(None, 36)
        sm_text = smfont.render('Submit', True, 'white')

        btn = pygame.draw.rect(screen, self.btncolor, [749,160, 100, 40 ])

        sm_text_rect = sm_text.get_rect()
        sm_text_rect.center = btn.center
        screen.blit(sm_text, sm_text_rect)

        # Get mouse position
        pos = pygame.mouse.get_pos()

        if btn.collidepoint(pos):
                self.btncolor = 'dodgerblue'
                pygame.mouse.set_cursor(pygame.SYSTEM_CURSOR_HAND)
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if len(self.name) > 0:
                        db.insert(''.join(self.name), player.score)
                        return True
        else:
            pygame.mouse.set_cursor() 
            self.btncolor = 'royalblue'
        return False    


class Form:
    ''' Form page is for making database entries '''
    def __init__(self, screen, player):
        music = abient.Music(path)
        bgimg = pygame.image.load(f'{path}/media/images/backgrounds/formbg.jpg')
        bgimg_rect = bgimg.get_rect()

        textbox = TextBox('Enter Initials:')

        while True:
            # Play the background music
            if not pygame.mixer.music.get_busy():
                music.play()

            # Blit the background image
            screen.blit(bgimg, bgimg_rect)

            # Get pygame events
            event = pygame.event.poll()
            if event.type == pygame.QUIT:
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    sys.exit()

            # Display the form. We get a return values if submitted
            ok = textbox.myevents(event, screen, player)
            textbox.update()
            textbox.draw(screen)

            # If return is True break and go to start page
            if ok:
                break

            pygame.display.update()