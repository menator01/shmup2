 download the shmup.tar.gz, music.tar.gz, and sounds.tar.gz
 Extract all files
 Place the sounds and music folders in the shmup media folder

The game is written using python3.12 and the pygame 2.5.2 and sqlite3
These will need to be installed
 
 enjoy
