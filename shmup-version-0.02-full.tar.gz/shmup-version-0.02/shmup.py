import pygame
from modules import abient, pages, character, mysprites, display
from modules.character import player_sprite, mob_sprite, weapon_sprite
from modules.powerups import PowerUp, power_sprite, Shield, shield_sprite
from modules.effects import Explosion
import os
from random import random, randrange

# Initiate pygame
pygame.init()

# pygame clock
clock = pygame.time.Clock()

# Get the working directory path
path = os.path.realpath(os.path.dirname(__file__))

# Setup screen window
screen = pygame.display.set_mode((1280, 720))
pygame.display.set_caption('Shmup')

# Background music and image
music = abient.Music(path)
bgimg = pygame.image.load(f'{path}/media/images/backgrounds/space.png')
bgimg_rect = bgimg.get_rect()

# Set some variables
gameover = True
doform = False

# Start the game loop
while True:
    # Start the background music
    if not pygame.mixer.music.get_busy():
        music.play()

    # Display the background image
    screen.blit(bgimg, bgimg_rect)

    # Poll pygame events
    event = pygame.event.poll()

    # Ways to exit the game
    if event.type == pygame.QUIT:
        break

    # Has a key been pressed
    if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_ESCAPE:
            break

        # This is just for testing purposes and will be removed
        if event.key == pygame.K_f:
            mysprites.allsprites.empty()
            doform = True

        # Fire weapons
        if event.key == pygame.K_m:
            player.missile()

        # We don't want the laser to fire without catching the icon first
        if player.laser_fire:
            if event.key == pygame.K_l:
                player.laser()
        else:
            player.laser_fire = False

    # We are not playing yet. Go to start title page
    if gameover:
        pages.Title(screen)
        gameover = False
        player = character.Player(path)
        shield = Shield(path)

        # Create some starting mobs
        for i in range(randrange(8, 10)):
            mob = character.Mob(path)

        # Used for displaying the three life ships
        col = 0
        for i in range(3):
            ship = display.Hud(path, 1120+col)
            col += 60
            ship.newship()
            
    # Is the game over? Do we need to go to the form
    if doform:
        pages.Form(screen, player)
        doform = False
        gameover = True

    # Statusbars - Displays the info across the top including the life ships
    display.StatusBar(screen, 100, 15, player.life, text='Life')
    display.StatusBar(screen, 100, 45, shield.strength, text='Shield')
    ship.hud_sprites.update()
    ship.hud_sprites.draw(screen)
    display.Score(screen, player.score)
    display.Tips(screen, 880, 680)



    # If player looses a life, remove ship from top
    for item in ship.hud_sprites:
        if len(ship.hud_sprites) > player.lives:
            ship.hud_sprites.remove(item)

    # Draw and update all the sprites
    mysprites.allsprites.update()
    mysprites.allsprites.draw(screen)

    # Having to keep these seperate from allsprites to detect collisions
    mob_sprite.update()
    mob_sprite.draw(screen)
    display.show_sprite.update()
    display.show_sprite.draw(screen)
    
    # Set weapon to True will get destroyed
    weapon = True

    # Loop through weapon_sprite if weapon type is laser, 
    # set weapon to True. laser will not be destroyed
    for weapons in weapon_sprite:
        weapon = True if weapons.type == 'missile' else False

    # Check for weapon hitting mob
    weaponhits = pygame.sprite.groupcollide(weapon_sprite, mob_sprite, weapon, True)
    for weaponhit in weaponhits:
        character.Mob(path)
        player.score += int(mob.radius * random())
        Explosion(path, weaponhit.rect.center)
        if random() > 0.8:
            PowerUp(path, weaponhit.rect.center)

    #Detect powerup hit
    powerhits = pygame.sprite.groupcollide(power_sprite, player_sprite, True, False)
    
    # Loop through the powerup and apply accordingly 
    for powerhit in powerhits:

        # Caught a shield icon
        if powerhit.type == 'shield':
            for shield in shield_sprite:
                shield.kill()
            shield = Shield(path)
            shield.strength = 100
            shield.raise_shield(player.rect.centerx, player.rect.top)
            show_shield = display.Show(path, 'shield.png', 1195, 690)
            display.show_sprite.add(show_shield)

        # Caught a partial heal icon
        if powerhit.type == 'heal':
            sound = pygame.mixer.Sound(f'{path}/media/sounds/partial_heal.wav')
            sound.set_volume(0.9)
            sound.play()
            if player.life == 100:
                player.score += int(player.life * random())
            else:
                player.life += int(player.life * random())
                if player.life > 100:
                    player.life = 100

        # Caught a laser icon
        if powerhit.type == 'laser':
            player.laser_timer = pygame.time.get_ticks()
            player.laser_fire = True
            laser = display.Show(path, 'laser2.png', 1165, 690)
            display.show_sprite.add(laser)

        # Caught a full heal icon
        if powerhit.type == 'fullheal':
            sound = pygame.mixer.Sound(f'{path}/media/sounds/full_heal.wav')
            sound.set_volume(0.9)
            sound.play()
            if player.life == 100:
                player.score += int(randrange(10, 50) * random())
            else:
                player.life = 100

        # Timer for laser. Laser ends after 10 seconds unless another
        # laser powerup is caught
        if player.laser_timer:
            if pygame.time.get_ticks() - player.laser_timer > 10000:
                player.laser_fire = False
                player.laser_timer = None

                # Laser end remove from icon from game screen
                for item in display.show_sprite:
                    if item.type == 'laser2':
                        item.kill()      

    # Checking for mobs hitting the shield
    shieldhits = pygame.sprite.groupcollide(mob_sprite, shield_sprite, True, False)
    for shieldhit in shieldhits:
        mob = character.Mob(path)
        Explosion(path, shieldhit.rect.center)

        # Shield was hit, remove some of the strength
        shield.strength -= int(shield.radius *0.3)

        # Shield strength reached 0, remove it
        if shield.strength <= 1:
            shield.strength = 0
            for item in shield_sprite:
                item.kill()
            shield.hidden = True

            # Lost shield remove icon from the game screen
            for item in display.show_sprite:
                if item.type == 'shield':
                    item.kill()
        

    # Player takes hits from mobs
    ship_destroy = False
    if player.life <= 0:
        ship_destroy = True
        player.lives -= 1
        player.life = 100
        player.hide()
        player.laser_fire = False
        player.laser_timer = None
        display.show_sprite.empty()

    # If player looses all lifes, reset everything and go to form
    if player.lives <= 0 and not player.explosion.alive():
        mysprites.allsprites.empty()
        display.show_sprite.empty()
        mob_sprite.empty()
        shield_sprite.empty()
        ship.hud_sprites.empty()
        doform = True

    # Detect if any mobs has hit the player. We need to create a newmob for the one killed
    mobhits = pygame.sprite.groupcollide(mob_sprite, player_sprite, True, False)
    for mobhit in mobhits:
        Explosion(path, mobhit.rect.center)
        player.life -= int(mobhit.radius)
        character.Mob(path)

    # Update the display
    pygame.display.update()
    clock.tick(60)

pygame.quit()