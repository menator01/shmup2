import pygame

class Missile(pygame.sprite.Sprite):
    ''' Class for the missle shot by player '''
    def __init__(self, x, y, path):
        pygame.sprite.Sprite.__init__(self)
        img = pygame.image.load(f'{path}/media/images/ammo/missile.png')
        self.image = pygame.transform.scale(img, (18, 32))
        self.image.set_colorkey('black')
        self.rect = self.image.get_rect()
        self.rect.bottom = y + 10
        self.rect.centerx = x
        self.speedy = -8
        self.type = 'missile'
        sound = pygame.mixer.Sound(f'{path}/media/sounds/rocket_fire.wav')
        sound.set_volume(0.3)
        sound.play()        

    def update(self):
        ''' Method for updating missile movement '''
        self.rect.y += self.speedy
        if self.rect.bottom < 0:
            self.kill()

class Laser(pygame.sprite.Sprite):
    ''' Laser class that creates the laser for player '''
    def __init__(self, x, y, path):
        pygame.sprite.Sprite.__init__(self)
        img = pygame.image.load(f'{path}/media/images/ammo/laser.png')
        self.image = pygame.transform.scale(img, (2, 120)).convert()
        self.image.set_colorkey('black')
        self.rect = self.image.get_rect()
        self.rect.bottom = y + 10
        self.rect.centerx = x
        self.speedy = -9
        self.type = 'laser'
        sound = pygame.mixer.Sound(f'{path}/media/sounds/laser.wav')
        sound.set_volume(0.4)
        sound.play()

    def update(self):
        ''' Method for updating laser movement '''
        self.rect.y += self.speedy
        if self.rect.bottom  < 0:
            self.kill()