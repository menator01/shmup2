# Import needed modules
import sqlite3

class Database:
    ''' Database class handles all database actions '''
    def __init__(self, path):
        ''' Create the database and cursor '''
        self.connect = sqlite3.connect(f'{path}/shmup.db')
        self.cursor = self.connect.cursor()

    def create(self):
        ''' Method for creating the table '''
        query = '''
            create table if not exists scores (
            id integer primary key,
            name text not null,
            score integer default 0,
            timestamp datetime default current_timestamp
            );
        '''
        # Execute and commit / save to the database
        self.connect.execute(query)
        self.connect.commit()

    def insert(self, name, score):
        ''' Method for entering data '''
        query = ''' insert into scores (name, score) values (?, ?);'''
        self.cursor.execute(query, (name, score))
        self.connect.commit()

    def top5(self):
        ''' Method for getting top scores '''
        query = '''
        select name, score, strftime('%m/%d/%Y', timestamp) \
        from scores order by score desc limit 5;
        '''
        return self.cursor.execute(query).fetchall()