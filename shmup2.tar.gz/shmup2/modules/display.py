import pygame
from modules.mysprites import allsprites

pygame.font.init()
# statusbar_sprite = pygame.sprite.Group()

class StatusBar:
    ''' This class creates the life and shield bars on the game screen '''
    def __init__(self, screen, x, y, status, text=''):
        font = pygame.font.Font(None, 30)
        surf = font.render(text, True, pygame.Color(255,255,255))
        
        fill = int((status / 100) * 100)   
        colors = {100:(0,255,0), 90: (153,255,51), 80: (178,255,102),
        70: (255,255,153), 60: (255,178,102), 50: (255,128,0),
        40: (235,78,20), 30: (255,69,0), 20: (255,0,0), 0: (0,0,0),
        0:  (0,0,0)}

        color = pygame.Color(0,255,0)
        for key, value in colors.items():
            if fill <= key:
                color = pygame.Color(value)

        screen.blit(surf, (x-85, y))
            
        fill_rect = pygame.Rect(x, y, fill, 15)
        pygame.draw.rect(screen, color, fill_rect)

        outline = pygame.Rect(x, y, 100, 15)
        pygame.draw.rect(screen, 'white', outline, 1)


class Score:
    ''' Class for displaying the score on the game window '''
    def __init__(self, screen, score):
        font = pygame.font.Font(None, 40)
        surf = font.render(f'Score: {score}', False, pygame.Color(255,255,255))

        screen.blit(surf, (screen.get_rect().width/2, 15))


class Tips:
    ''' Provides the tip on keys to push for weapon fire '''
    def __init__(self, screen, x, y):
        font = pygame.font.Font(None, 35)
        surf = font.render('M = Rocket | L = Laser', True, pygame.Color(255,255,255))
        screen.blit(surf, (x, y))     
        

class Hud(pygame.sprite.Sprite):
    ''' The Hud classes is for displaying the life ships on the game window '''
    # Creates a sprite group
    hud_sprites = pygame.sprite.Group()
    def __init__(self, path, x):
        pygame.sprite.Sprite.__init__(self)
        self.path = path
        img = pygame.image.load(f'{self.path}/media/images/ships/myship.png')
        self.image = pygame.transform.scale(img, (50, 50))
        self.image.set_colorkey('black')
        self.rect = self.image.get_rect()
        self.rect.top = 15
        self.rect.centerx = x

    def newship(self):
        ''' Method create a new instance and adds to sprite group '''
        ship = self
        Hud.hud_sprites.add(ship)