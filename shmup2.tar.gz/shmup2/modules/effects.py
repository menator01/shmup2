import pygame
import os
from modules.mysprites import allsprites

class Explosion(pygame.sprite.Sprite):
    ''' This class creates and handles the explosion animation on the game screen '''
    def __init__(self, path, rect):
        pygame.sprite.Sprite.__init__(self)
        self.path = path
        self.frame = 0
        imgpath = f'{path}/media/images/animation/enemy'
        files = os.listdir(imgpath)
        self.myimgs = []
        for i, file in enumerate(files):
            file = pygame.image.load(f'{imgpath}/explosion1_{i}.png')
            self.myimgs.append(file)
        self.image = self.myimgs[0]
        self.rect = self.image.get_rect()
        self.rect.center = rect
        sound = pygame.mixer.Sound(f'{path}/media/sounds/explosion.wav')
        sound.set_volume(0.3)
        sound.play()

        allsprites.add(self)
        
    def update(self):
        self.frame += 1
        if self.frame >= len(self.myimgs):
            self.kill()
        else:
            self.image = self.myimgs[self.frame] 