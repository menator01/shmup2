import pygame
allsprites = pygame.sprite.Group()


