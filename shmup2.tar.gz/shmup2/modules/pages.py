import sys, os
from modules import abient, database
import pygame
from random import choice

pygame.font.init()
tmp = os.path.realpath(os.path.dirname(__file__)).split('/')
tmp.pop()
path = '/'.join(tmp)


# Function to create text labels
def label(text, size, color, font, x=0, y=0, underline=False):   
    font = pygame.font.Font(f'{path}/media/fonts/{font}', size)
    font.underline=underline
    text = font.render(text, True, color)
    width = 1280
    text_w = text.get_rect().width
    pos = ((width/2-text_w/2)+x, y)
    return text, pos

labels = []
labels.append(label('Shmup', 80, (0,0,0), 'Nosifer-Regular.ttf', x=3, y=3))
labels.append(label('Shmup', 80, (255,0,255), 'Nosifer-Regular.ttf'))

labels.append(label('Beta Version 0.02', 22, (0,0,0), 'FreeMonoBoldOblique.ttf', x=1283/3, y=38))
labels.append(label('Beta Version 0.02', 22, (200,200,200), 'FreeMonoBoldOblique.ttf', x=1280/3, y=35))

labels.append(label('Powered by pygame 2.5.2 (SDL 2.28.2, Python 3.12.0)', 22, (0,0,0), 'FreeMonoBoldOblique.ttf', x=3, y=123))
labels.append(label('Powered by pygame 2.5.2 (SDL 2.28.2, Python 3.12.0)', 22, 'lime', 'FreeMonoBoldOblique.ttf', y=120))

labels.append(label('Top 5 Scores', 45, 'black', 'Nosifer-Regular.ttf', x=3, y=153, underline=True))
labels.append(label('Top 5 Scores', 45, 'orange', 'Nosifer-Regular.ttf', y=150, underline=True))

labels.append(label(f'Gaming-Rat Productions{chr(169)} 2020', 22, (0,0,0), 'FreeMonoBoldOblique.ttf',x=-374, y=672))
labels.append(label(f'Gaming-Rat Productions{chr(169)} 2020', 22, (255,230,230), 'FreeMonoBoldOblique.ttf',x=-376, y=670))

labels.append(label('Press spacebar to start', 35, (0,0,0), 'calibri.ttf', y=720-220))
labels.append(label('Gives Shield', 32, (0,0,0), 'calibri.ttf', x=-295, y=600))
labels.append(label('Partial Health', 30, (0,0,0), 'calibri.ttf', x=0, y=600))
labels.append(label('Full Health', 32, (0,0,0), 'calibri.ttf', x=295, y=600))


# Make a list of ships in the ship directory
ships = os.listdir(f'{path}/media/images/ships')

# Function for placing images
def placeimg(rotate, apath, ship, width=64, height=64):
    img = pygame.image.load(f'{path}/{apath}/{ship}')
    img = pygame.transform.scale(img, (width, height))
    img = pygame.transform.rotate(img, rotate)
    img.set_colorkey('black')
    return img

# Create some images for the screen
ship1 = placeimg(45, 'media/images/ships',choice(ships))
ship2 = placeimg(-45, 'media/images/ships', choice(ships))

shield = placeimg(0, 'media/images/powerups', 'shield.png', width=48, height=48)
health1 = placeimg(0, 'media/images/powerups', 'partial_life.png', width=48, height=48)
health2 = placeimg(0, 'media/images/powerups', 'full_life.png', width=48, height=48)

logo = pygame.image.load(f'{path}/media/images/icons/ratt2b.bmp')

# Connect, create, and query database
db = database.Database(path)
db.create()
gamers = db.top5()

# Starting index for entry placements on the screen
index = 220
for data in gamers:
    name, score, date = data
    labels.append(label(f'{name.upper()} {score} {date}', 35, 'black', 'calibri.ttf', x=2, y=index+2))
    labels.append(label(f'{name.upper()} {score} {date}', 35, 'white', 'calibri.ttf', y=index))
    index += 50

class Title:
    ''' Class is the start page when game is executed '''
    def __init__(self, screen):
        # Background music and image
        music = abient.Music(path)
        bgimg = pygame.image.load(f'{path}/media/images/backgrounds/title.jpeg')
        bgimg_rect = bgimg.get_rect()         

        while True:
            # For the background music
            if not pygame.mixer.music.get_busy():
                music.play()

            # Background image
            screen.blit(bgimg, bgimg_rect)

            # Icon images
            screen.blit(ship1, (180, 175))
            screen.blit(ship2, (1000, 175))

            screen.blit(shield, (315, 545))
            screen.blit(health1, (screen.get_rect().width/2-25, 545))
            screen.blit(health2, (905, 545))

            screen.blit(logo, (25,640))

            # Get pygame events
            event = pygame.event.poll()
            if event.type == pygame.QUIT:
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    sys.exit()
                if event.key == pygame.K_SPACE:
                    break

            for alabel in labels:
                screen.blit(alabel[0], alabel[1])


            pygame.display.update()


class Form:
    ''' Form page is for making database entries '''
    def __init__(self, screen):
        music = abient.Music(path)
        bgimg = pygame.image.load(f'{path}/media/images/backgrounds/formbg.jpg')
        bgimg_rect = bgimg.get_rect()

        # Temp label
        shadow = label('Press Enter to exit this screen', 40, (0,0,0), 'calibri.ttf',x=2, y=202)
        lab = label('Press Enter to exit this screen', 40, (255,200,255), 'calibri.ttf',y=200)

        shadow2 = label('ESC to quit', 40, (0,0,0), 'calibri.ttf', x=-150, y=252)
        lab2 = label('ESC to quit', 40, (255,200,255), 'calibri.ttf',x =-152, y=250)
        
        while True:
            if not pygame.mixer.music.get_busy():
                music.play()

            screen.blit(bgimg, bgimg_rect)

            screen.blit(shadow[0], shadow[1])
            screen.blit(lab[0], lab[1])

            screen.blit(shadow2[0], shadow2[1])
            screen.blit(lab2[0], lab2[1])

            event = pygame.event.poll()
            if event.type == pygame.QUIT:
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    sys.exit()
                if event.key == pygame.K_RETURN or event.key == pygame.K_KP_ENTER:
                    break
            pygame.display.update()