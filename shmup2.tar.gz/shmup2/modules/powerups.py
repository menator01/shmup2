import pygame
import os
from random import choice
from modules.mysprites import allsprites

power_sprite = pygame.sprite.Group()
shield_sprite = pygame.sprite.Group()

class PowerUp(pygame.sprite.Sprite):
    def __init__(self, path, center):
        pygame.sprite.Sprite.__init__(self)
        self.path = path
        self.center = center

        powerups = os.listdir(f'{path}/media/images/powerups')
        powerup = {'heal': 'partial_life.png', 'fullheal': 'full_life.png',
                    'shield': 'shield.png'}
        self.type = choice(list(powerup))
        
        img = powerup[self.type]
        self.image = pygame.image.load(f'{path}/media/images/powerups/{img}')
        self.image.set_colorkey('black')
        self.rect = self.image.get_rect()
        self.rect.center = center
        self.speedy = 2

        power_sprite.add(self)
        allsprites.add(self)

        
    def update(self):
        self.rect.y += self.speedy
        if self.rect.top > 720:
            self.kill()


class Shield(pygame.sprite.Sprite):
    ''' This class creates the shield over the player ship when touched by the shield images '''
    def __init__ (self, path):
        self.path = path
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(f'{path}/media/images/shield/shield_100.png')
        self.image = pygame.transform.scale(self.image, (75, 70))
        self.image.set_colorkey('black')
        self.rect = self.image.get_rect()
        self.radius = 30
        self.rect.centerx = 640
        self.rect.top = 765
        self.strength = 0
        self.hidden = True

    def raise_shield(self, x, y):
        Shield(self.path)
        self.hidden = False
        self.strength = 100
        self.rect.centerx = x
        self.rect.top = y - 8
        shield_sprite.add(self)
        allsprites.add(self)
        sound = pygame.mixer.Sound(f'{self.path}/media/sounds/shield_up.wav')
        sound.set_volume(0.9)
        sound.play()


    def update(self):
        if self.hidden:
            self.kill()
        self.speedx = 0
        keystate = pygame.key.get_pressed()
        if keystate[pygame.K_LEFT] or keystate[pygame.K_a]:
            self.speedx = -8
        if keystate[pygame.K_RIGHT] or keystate[pygame.K_d]:
            self.speedx = 8
        
        self.rect.x += self.speedx

        if self.rect.right > 1278:
            self.rect.right = 1278
        if self.rect.left < 3:
            self.rect.left = 3

        if self.strength > 75:
            self.image = pygame.image.load(f'{self.path}/media/images/shield/shield_100.png')
            self.image = pygame.transform.scale(self.image, (75, 70))
            self.image.set_colorkey('black')

            shield_sprite.add(self)
            allsprites.add(self)

        if self.strength <= 75:
            self.image = pygame.image.load(f'{self.path}/media/images/shield/shield_75.png')
            self.image = pygame.transform.scale(self.image, (75, 70))
            self.image.set_colorkey('black')

            shield_sprite.add(self)
            allsprites.add(self)

        if self.strength <= 50:
            self.image = pygame.image.load(f'{self.path}/media/images/shield/shield_50.png')
            self.image = pygame.transform.scale(self.image, (75, 70))
            self.image.set_colorkey('black')
            
            shield_sprite.add(self)
            allsprites.add(self)

        if self.strength <= 25:
            self.image = pygame.image.load(f'{self.path}/media/images/shield/shield_25.png')
            self.image = pygame.transform.scale(self.image, (75, 70))
            self.image.set_colorkey('black')
            
            shield_sprite.add(self)
            allsprites.add(self)

        if self.strength <= 0:
            self.hidden = True
            self.kill() 