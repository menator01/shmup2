 download the shmup.tar.gz, music.tar.gz, and sounds.tar.gz
 Extract all files
 Place the sounds and music folders in the shmup media folder

 
 enjoy
