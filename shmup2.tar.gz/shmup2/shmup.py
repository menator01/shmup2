import pygame
from modules import abient, pages, database, character, mysprites, display
from modules.character import player_sprite, mob_sprite, weapon_sprite
from modules.powerups import PowerUp, power_sprite, Shield, shield_sprite
from modules.effects import Explosion
import os, math
from random import random, randrange


# Initiate pygame
pygame.init()

clock = pygame.time.Clock()

# Get the working directory path
path = os.path.realpath(os.path.dirname(__file__))

# Setup screen window
screen = pygame.display.set_mode((1280, 720))
pygame.display.set_caption('Shmup')

# Background music and image
music = abient.Music(path)
bgimg = pygame.image.load(f'{path}/media/images/backgrounds/space.png')
bgimg_rect = bgimg.get_rect()

# Set some variables
gameover = True
doform = False


# Start the game loop
while True:
    # Start the background music
    if not pygame.mixer.music.get_busy():
        music.play()
    screen.blit(bgimg, bgimg_rect)

    # Poll pygame events
    event = pygame.event.poll()

    # Ways to exit the game
    if event.type == pygame.QUIT:
        break

    if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_ESCAPE:
            break

        if event.key == pygame.K_f:
            mysprites.allsprites.empty()
            doform = True

        # Fire weapons
        if event.key == pygame.K_m:
            player.missile()

        if event.key == pygame.K_l:
            player.laser()

    # We are not playing yet. Go to start title page
    if gameover:
        pages.Title(screen)
        gameover = False
        player = character.Player(path)
        shield = Shield(path)

        # Create some starting mobs
        for i in range(randrange(8, 10)):
            character.Mob(path)

        col = 0
        for i in range(3):
            ship = display.Hud(path, 1120+col)
            col += 60
            ship.newship()
            
    # Is the game over? Do we need to go to the form
    if doform:
        pages.Form(screen)
        doform = False
        gameover = True

    # Statusbars
    display.StatusBar(screen, 100, 15, player.life, text='Life')
    display.StatusBar(screen, 100, 45, shield.strength, text='Shield')
    ship.hud_sprites.update()
    ship.hud_sprites.draw(screen)
    display.Score(screen, player.score)
    display.Tips(screen, 880, 680)

    # Draw and update all the sprites
    mysprites.allsprites.update()
    mysprites.allsprites.draw(screen)
    
    # Set weapon to True will get destroyed
    weapon = True
    # Loop through weapon_sprite if weapon type is laser, 
    # set weapon to True. laser will not be destroyed
    for weapons in weapon_sprite:
        weapon = True if weapons.type == 'missile' else False

    # Check for weapon hitting mob
    weaponhits = pygame.sprite.groupcollide(weapon_sprite, mob_sprite, weapon, True)
    for weaponhit in weaponhits:
        character.Mob(path)
        Explosion(path, weaponhit.rect.center)
        if random() > 0.8:
            PowerUp(path, weaponhit.rect.center)

    #Detect powerup hit
    powerhits = pygame.sprite.groupcollide(power_sprite, player_sprite, True, False)
    
    # Loop through the powerup and apply accordingly 
    for powerhit in powerhits:
        if powerhit.type == 'shield':
            for shield in shield_sprite:
                shield.kill()
            shield = Shield(path)
            shield.strength = 100
            shield.raise_shield(player.rect.centerx, player.rect.top)

        if powerhit.type == 'heal':
            sound = pygame.mixer.Sound(f'{path}/media/sounds/partial_heal.wav')
            sound.set_volume(0.9)
            sound.play()
            if player.life == 100:
                player.score += int(player.life * 0.25)
            else:
                player.life += int(player.life * 0.25)
                if player.life > 100:
                    player.life = 100

        if powerhit.type == 'fullheal':
            sound = pygame.mixer.Sound(f'{path}/media/sounds/full_heal.wav')
            sound.set_volume(0.9)
            sound.play()
            if player.life == 100:
                player.score += randrange(10, 50)
            else:
                player.life = 100

    # Checking for mobs hitting the shield
    shieldhits = pygame.sprite.groupcollide(mob_sprite, shield_sprite, True, False)
    for shieldhit in shieldhits:
        character.Mob(path)

        # Shield was hit, remove some of the strength
        shield.strength -= int(shield.radius *0.3)

        # Shield strength reached 0, remove it
        if shield.strength <= 0:
            shield.strength = 0
            shield.hidden = True
            for item in shield_sprite:
                item.kill()

    # Update the display
    pygame.display.update()
    clock.tick(60)

pygame.quit()